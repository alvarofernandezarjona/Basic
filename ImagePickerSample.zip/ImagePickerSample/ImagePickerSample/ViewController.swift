//
//  ViewController.swift
//  ImagePickerSample
//
//  Created by Alvaro Fernandez Arjona on 15/06/16.
//  Copyright © 2016 Alvaro Fernandez Arjona. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate{

    @IBOutlet weak var imageView:UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func camara(sender:UIButton) {
        let picker = UIImagePickerController()
        picker.sourceType = .camera
        self.present(picker, animated: true, completion: nil)
    }
    
    @IBAction func library(sender:UIButton) {
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        self.present(picker, animated: true, completion: nil)
    }
    
    // MARK: ImagePickerController
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        let pickedImage:UIImage = ((info[UIImagePickerControllerOriginalImage]) as? UIImage)! // Resulting image = pickedImage
        imageView.image = pickedImage
        picker.dismiss(animated: true, completion: nil)
    }
}

